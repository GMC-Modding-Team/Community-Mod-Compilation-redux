#!/usr/bin/env python3
"""Generate valid CDDA-shaped JSON files for editor load/search tests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


RECORD = {
    "type": "vehicle",
    "id": "test_stream_vehicle",
    "name": {"str": "streaming test vehicle"},
    "parts": [
        {"x": 0, "y": 0, "parts": ["frame", "seat", "controls"]},
        {"x": 1, "y": 0, "parts": ["frame", "small_motor", "battery_car"]},
        {"x": -1, "y": -1, "parts": ["frame", "wheel"]},
        {"x": 2, "y": 1, "parts": ["frame", "wheel_steerable"]},
    ],
    "test_regex_value": "streaming-search-target",
}


def write_fixture(path: Path, target_bytes: int) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    record_number = 0
    written = 0
    record_text = json.dumps(RECORD, separators=(",", ":"))

    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("[\n")
        written += 2
        while written + len(record_text) + 3 < target_bytes:
            if record_number:
                handle.write(",\n")
                written += 2
            current = record_text.replace("test_stream_vehicle", f"test_stream_vehicle_{record_number}")
            handle.write(current)
            written += len(current.encode("utf-8"))
            record_number += 1
        handle.write("\n]\n")
        written += 3

    return written


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output_dir", type=Path)
    parser.add_argument(
        "--sizes",
        nargs="+",
        type=int,
        default=[1, 10, 100],
        help="target sizes in MiB (default: 1 10 100)",
    )
    args = parser.parse_args()

    for size in args.sizes:
        if size < 1:
            raise SystemExit("fixture sizes must be positive")
        output = args.output_dir / f"json_editor_{size}MiB.json"
        actual = write_fixture(output, size * 1024 * 1024)
        print(f"{output}: {actual:,} bytes")


if __name__ == "__main__":
    main()
