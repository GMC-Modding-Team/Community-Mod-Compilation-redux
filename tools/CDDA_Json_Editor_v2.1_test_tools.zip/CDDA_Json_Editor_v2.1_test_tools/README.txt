JSON Editor v2.1 load-test fixtures

Generate the default 1 MiB, 10 MiB, and 100 MiB valid JSON files with:

python tests/generate_json_fixtures.py tests/fixtures

Use the fixtures to check:
- cancellable file loading and progress status
- Next/Previous search for "streaming-search-target"
- selection and scroll retention when switching tabs
- wrapped line-number alignment

The files are generated locally and are not included in the application bundle.
