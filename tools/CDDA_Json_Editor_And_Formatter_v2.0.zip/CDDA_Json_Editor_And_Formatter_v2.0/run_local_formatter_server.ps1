$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

if (Get-Command py -ErrorAction SilentlyContinue) {
    py -3 "$here\local_formatter_server.py"
    exit $LASTEXITCODE
}

if (Get-Command python -ErrorAction SilentlyContinue) {
    python "$here\local_formatter_server.py"
    exit $LASTEXITCODE
}

Write-Host "Python 3 was not found. Install Python 3, then run this file again."
