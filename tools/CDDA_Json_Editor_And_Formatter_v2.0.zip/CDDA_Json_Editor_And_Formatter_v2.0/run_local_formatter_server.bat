@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0local_formatter_server.py"
  goto :eof
)

where python >nul 2>nul
if %errorlevel%==0 (
  python "%~dp0local_formatter_server.py"
  goto :eof
)

echo Python 3 was not found.
echo Install Python 3, then run this file again.
pause
