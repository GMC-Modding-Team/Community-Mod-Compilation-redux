CDDA Json Editor And Formatter v2.0

Working editor
Working Cdda Formatter
Working Minify
Working colored text
working open/save json
working cdda validate

v2.0 additions
settings panel with saved feature toggles and editor controls
Structure and Validation panels can be toggled independently in Settings
font-size control, cancellable file loading, and per-tab scroll/selection restoration
tabs can be reordered by dragging, with shortcuts for new and close tab
optional workspace restore reopens smaller tabs after refresh; huge files are excluded
regex-aware replace-current and replace-all actions
regex and plain-text search with case matching
previous and next search navigation (Ctrl+F and F3)
line numbers with large-file safeguards
multiple tabs with open-file tab creation
multi-select Open JSON to view several files in separate tabs
compare view shows two open files side by side while the active file remains editable
drag and drop one or more JSON files onto the editor to open them in tabs
vehicle validation checks modern parts placements, coordinates, and duplicate tiles
chunked File.stream() loading with progress
regex match coloring that pauses automatically for very large files
scroll synchronization for syntax colors, regex matches, and line numbers

how to use correctly

step 1
run run_local_formatter_server.bat

step 2
run cdda_json_color_editor_local_formatter.html
