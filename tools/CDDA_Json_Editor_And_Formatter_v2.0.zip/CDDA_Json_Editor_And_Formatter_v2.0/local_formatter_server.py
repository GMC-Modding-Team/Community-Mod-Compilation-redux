import json
import subprocess
import tempfile
import urllib.parse
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST = "127.0.0.1"
PORT = 8765
ROOT = Path(__file__).resolve().parent
FORMATTER_EXE = ROOT / "json_formatter.exe"


def _clean_stdout(stdout_text: str) -> str:
    text = stdout_text.replace("\r\n", "\n")
    if text.lower().startswith("content-type:"):
        parts = text.split("\n\n", 1)
        if len(parts) == 2:
            text = parts[1]
    return text.strip("\ufeff")


def _run_cgi_mode(raw_text: str):
    body = "data=" + urllib.parse.quote(raw_text, safe="")
    env = os.environ.copy()
    env.update({
        "REQUEST_METHOD": "POST",
        "CONTENT_TYPE": "application/x-www-form-urlencoded",
        "CONTENT_LENGTH": str(len(body.encode("utf-8"))),
        "GATEWAY_INTERFACE": "CGI/1.1",
        "SERVER_PROTOCOL": "HTTP/1.1",
        "REQUEST_URI": "/tools/format/json_formatter.cgi",
        "SCRIPT_NAME": "/tools/format/json_formatter.cgi",
    })
    proc = subprocess.run(
        [str(FORMATTER_EXE)],
        input=body,
        capture_output=True,
        text=True,
        timeout=20,
        cwd=str(ROOT),
        env=env,
    )
    stderr = (proc.stderr or "").strip()
    stdout = _clean_stdout(proc.stdout or "")
    if proc.returncode == 0 and stdout.strip():
        return stdout, None
    message = stderr or stdout or f"Formatter exited with code {proc.returncode}"
    return None, f"cgi mode: {message}"


def _run_file_mode(raw_text: str):
    with tempfile.TemporaryDirectory(prefix="cdda_jsonfmt_") as tmpdir:
        temp_json = Path(tmpdir) / "input.json"
        temp_json.write_text(raw_text, encoding="utf-8", newline="\n")
        proc = subprocess.run(
            [str(FORMATTER_EXE), str(temp_json)],
            capture_output=True,
            text=True,
            timeout=20,
            cwd=str(ROOT)
        )
        formatted = temp_json.read_text(encoding="utf-8")
        stderr = (proc.stderr or "").strip()
        stdout = _clean_stdout(proc.stdout or "")
        if proc.returncode == 0:
            return formatted, None
        message = stderr or stdout or f"Formatter exited with code {proc.returncode}"
        return None, f"file mode: {message}"


def _run_stdin_mode(raw_text: str):
    proc = subprocess.run(
        [str(FORMATTER_EXE)],
        input=raw_text,
        capture_output=True,
        text=True,
        timeout=20,
        cwd=str(ROOT)
    )
    stderr = (proc.stderr or "").strip()
    stdout = _clean_stdout(proc.stdout or "")
    if proc.returncode == 0 and stdout.strip():
        return stdout, None
    message = stderr or stdout or f"Formatter exited with code {proc.returncode}"
    return None, f"stdin mode: {message}"


def format_with_exe(raw_text: str) -> str:
    if not FORMATTER_EXE.exists():
        raise FileNotFoundError(f"Formatter not found: {FORMATTER_EXE}")

    for runner in (_run_cgi_mode, _run_file_mode, _run_stdin_mode):
        result, error = runner(raw_text)
        if result is not None:
            return result
        last_error = error

    raise RuntimeError(
        "Formatter failed in all modes.\n"
        f"{last_error}"
    )


class Handler(BaseHTTPRequestHandler):
    server_version = "CDDALocalFormatter/3.0"

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def log_message(self, fmt, *args):
        print("%s - - [%s] %s" % (self.address_string(), self.log_date_time_string(), fmt % args))

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        if self.path == "/" or self.path == "/health":
            payload = {
                "ok": True,
                "formatter_exists": FORMATTER_EXE.exists(),
                "formatter_path": str(FORMATTER_EXE),
                "version": 3,
                "modes": ["cgi", "file", "stdin"],
            }
            body = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        if self.path != "/format":
            self.send_response(404)
            self.end_headers()
            return
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            raw_body = self.rfile.read(content_length)
            content_type = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            text_to_format = ""

            if content_type == "application/json":
                payload = json.loads(raw_body.decode("utf-8"))
                text_to_format = payload.get("data", "")
            elif content_type == "application/x-www-form-urlencoded":
                params = urllib.parse.parse_qs(raw_body.decode("utf-8"))
                text_to_format = params.get("data", [""])[0]
            else:
                text_to_format = raw_body.decode("utf-8")

            if not text_to_format.strip():
                raise ValueError("No JSON data provided.")

            formatted = format_with_exe(text_to_format)
            body = json.dumps({"formatted": formatted}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        except json.JSONDecodeError as e:
            message = f"Invalid request JSON: {e}"
            body = json.dumps({"error": message}).encode("utf-8")
            self.send_response(400)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            body = json.dumps({"error": str(e)}).encode("utf-8")
            self.send_response(400)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)


if __name__ == "__main__":
    if not FORMATTER_EXE.exists():
        print(f"Missing formatter: {FORMATTER_EXE}")
        raise SystemExit(1)

    print(f"Starting local formatter server on http://{HOST}:{PORT}")
    print(f"Using formatter: {FORMATTER_EXE}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
