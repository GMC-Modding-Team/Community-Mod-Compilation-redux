# G11 is more than a prototype thanks to Alien Space Bats 

Exactly what it says. Also adds the UCP pistol back, except now it is quite the hand cannon instead of just a competitor to the Five-seveN.

Replacing 4.6mm with 4.73mm caseless was a choice made for the sake of convenience so existing base game spawn lists can be reused. In this "timeline" H&K never invented 4.6mm.

If you would like to also replace all Rivtech 8x40mm guns, ammo and magazines with G11's 4.73mm caseless, just extract the .zip located in this folder and load your game again. This will really improve ammo availability for it.

Includes json configuration for @'s soundpack, just extract it if you have it.

Also available as a standalone mod if you would rather have it set up separatedly or only it. Don't unzip this integrated version if you already have the standalone one activated in the world gen settings.